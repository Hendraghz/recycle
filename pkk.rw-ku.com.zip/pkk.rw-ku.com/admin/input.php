<?php

include '../koneksi.php';

$nama = $_POST['nama'];
$username = $_POST['username'];
$notelp = $_POST['notelp'];
$asal = $_POST['asal'];
$sampah_organik = $_POST['sampah_organik'];
$rw = $_POST['rw'];
$rt = $_POST['rt'];
$kelurahan = $_POST['kelurahan'];
$kecamatan = $_POST['kecamatan'];
$edukasi = $_POST['edukasi'];
$rumah = $_POST['rumah'];


$result = mysqli_query($koneksi, "INSERT INTO input VALUES('','$nama','$username','$notelp','$asal','$sampah_organik','$rw','$rt','$kelurahan','$kecamatan','$edukasi','$rumah')");

if ($result) {
    $user = mysqli_query($koneksi, "SELECT nama FROM users WHERE username='$username'");
    if (mysqli_num_rows($user) > 0) {
        echo "<script>alert('Data berhasil ditambahkan!');window.location='input-data.php';</script>";
    }
} else {
    echo "<script>alert('Data gagal ditambahkan!');window.location='input-data.php';</script>";
}
